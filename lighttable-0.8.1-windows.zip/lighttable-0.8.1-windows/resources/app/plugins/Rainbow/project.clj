(defproject com.lighttable/rainbow "0.0.8"
  :description "Rainbow parens plugin for Light Table"
  :dependencies [[org.clojure/clojure "1.5.1"]])

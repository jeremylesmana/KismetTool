## 0.1.0

* Add codemirror addons for auto-closing tags and highlighting matching tags
* Add command to jump between matching tags

(defproject com.lighttable/html "0.0.1"
  :description "HTML language plugin for Light Table"
  :dependencies [[org.clojure/clojure "1.5.1"]])

# 0.2.0

* Fix acorn SyntaxError for returns outside fns
* Fix error message when connecting eval
* Add harbor dependency to plugin instead of depending on LT
* Rely on native js->clj instead of LT one
* Cleanup code indentation

## 0.1.3

* Add Node.js start parameters and corresponding behavior

## 0.1.2

* Fix require for es6-map
* Bump CM mode to 4.8.0
* Convert behaviors to flat format

## 0.1.1
* Fix shebang parsing

## 0.1.0
* Fix console.log and on-out behavior
* Upgrade to acorn 0.9.0

## 0.0.1 - 0.0.6
* See git history

##Changes

###0.0.7

* FIX: bug introduced in UTF8 handling

###0.0.6

* FIX: ensure that code and paths being compiled are encoded in utf8

###0.0.5

* FIX: pathing issues on windows
* FIX: remove the preset indentation, so that people can override at a global level.

###0.0.4

* UPDATE: latest CodeMirror python mode

###0.0.3

* FIX: ipython connections in Python 3

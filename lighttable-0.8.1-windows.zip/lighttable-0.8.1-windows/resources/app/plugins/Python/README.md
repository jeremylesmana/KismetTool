##Python for Light Table

The official Python language plugin for Light Table.

###License

Copyright (C) 2013 Kodowa Inc.

Distributed under the MIT license, see license.md for the full text.

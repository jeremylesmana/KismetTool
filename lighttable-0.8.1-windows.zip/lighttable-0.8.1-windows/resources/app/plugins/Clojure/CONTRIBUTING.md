See [LightTable's main CONTRIBUTING page](https://github.com/LightTable/LightTable/blob/master/CONTRIBUTING.md).
